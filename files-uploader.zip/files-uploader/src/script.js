 function fileList(e) {
    var files = $('#files').prop("files");
    var names = $.map(files, function(val) { return val.name; });
    for (n in names){
      $("#allfile").append('<div class="files" id="file-'+n+'">\n' +
        '        <div> '+names[n]+' </div>\n' +
        '        <div class="remove" onclick="deleteFile('+n+')"> X</div>\n' +
        '      </div>');
    }
  }

  function deleteFile(index)  {
    filelistall = $('#files').prop("files");
    var fileBuffer=[];
    Array.prototype.push.apply( fileBuffer, filelistall );
    fileBuffer.splice(index, 1);
    const dT = new ClipboardEvent('').clipboardData || new DataTransfer();
    for (let file of fileBuffer) { dT.items.add(file); }
    filelistall = $('#files').prop("files",dT.files);
    $("#file-"+index).addClass('removed-item')
      .one('webkitAnimationEnd oanimationend msAnimationEnd animationend', function(e) {
        $(this).remove();
      });
    setTimeout(function(){
      $("#allfile").empty();
      fileList();
      }, 1000);


  }